# BrightMart Retail Customer Analytics Using Machine Learning

End-to-end machine-learning mini project: a synthetic retail dataset is generated, audited and modelled with **Linear Regression**, **Decision Tree**, **K-Means** and **Random Forest** to answer three business questions — estimate sales from advertising spend, segment customers by income and spending behaviour, and predict campaign response.

> Mini project report — *Analytical Modelling with Machine Learning*
> **Ritick** (Roll No. 25MDA1018) · MBA Data Science & AI · Chandigarh University · Submitted to Mr. Kuldeep Dubey

## Project Structure

```
brightmart-ml-project/
├── data/
│   └── BrightMart_ML_Dataset.csv   # 600-record synthetic dataset (10 columns)
├── src/
│   └── brightmart_analysis.py      # full pipeline: data gen → audit → 4 models → figures → metrics
├── outputs/
│   ├── metrics.json                # every reported number, exported by the script
│   └── figures/                    # the 8 figures used in the report (PNG)
└── report/
    ├── 25MDA1018_Ritick_AnalyticalModellingML.pdf   # mini project report
    └── 25MDA1018_Ritick_AnalyticalModellingML.docx
```

## Dataset

`BrightMart_ML_Dataset.csv` — 600 customers × 10 columns:

| Column | Type | Description |
|---|---|---|
| Customer_ID | Text | Unique ID (C0001–C0600) |
| Age | Integer | 18–70 years |
| Annual_Income | Float | ₹ lakhs (24–150) |
| Spending_Score | Integer | Retailer-assigned, 1–100 |
| Purchase_Frequency | Integer | Purchases in the period (2–24) |
| Discount_Usage | Text | Low / Medium / High |
| Ad_Spend | Float | Advertising spend, ₹ thousands |
| Sales | Float | Attributable sales, ₹ thousands |
| Campaign_Response | Text | Responded to last promotion (Yes/No) |
| Customer_Segment | Text | Premium / Regular / Low-value |

## How to Run

```bash
pip install -r requirements.txt
python src/brightmart_analysis.py
```

The script regenerates the dataset, refits every model, rewrites `outputs/metrics.json` and all 8 figures from scratch.

## Key Results

| Model | Task | Result |
|---|---|---|
| Linear Regression | Sales ~ Ad_Spend | R² = 0.8768, MAE = ₹13.30k, slope = 1.7492 (r = 0.935) |
| K-Means (K = 3) | Segmentation | Premium Champions / Aspirational Enthusiasts / Budget Conscious |
| Decision Tree (depth 4) | Campaign response | 66.67% accuracy, F1 = 0.7436 |
| Random Forest (100 trees) | Campaign response | **76.67% accuracy, F1 = 0.8272**, missed responders cut 19 → 10 |

Budget rule: at ~57.2% gross margin an ₹80k campaign breaks even (predicted sales ≈ ₹170.7k).

## Reproducibility

Every stochastic step — data generation, the 80/20 train-test split and all four models — is pinned to `random_state = 1018`. Rerunning the script on any machine reproduces the dataset, every metric in `outputs/metrics.json` and every figure exactly.

## Tech Stack

Python 3 · pandas · NumPy · scikit-learn · Matplotlib · Pillow
