#!/usr/bin/env python3
"""
BrightMart Retail Customer Analytics using Machine Learning — full analysis run.
Generates a synthetic dataset (seed 1018), runs all four model experiments
(Linear Regression, Decision Tree, K-Means, Random Forest), saves 8 figures
to outputs/figures/ and a metrics.json to outputs/, consumed by the report.
Project layout: data/ (dataset), src/ (this script), outputs/ (metrics + figures).
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             mean_absolute_error, precision_score, r2_score,
                             recall_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier, plot_tree

SEED = 1018  # fixed for full reproducibility of dataset, split and models
N = 600
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
ASSETS = os.path.join(PROJECT_ROOT, "outputs")
FIGS = os.path.join(ASSETS, "figures")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(FIGS, exist_ok=True)

rng = np.random.default_rng(SEED)

# ---------------------------------------------------------------- palette
C_PRIMARY = "#4C72B0"   # muted blue
C_SECOND = "#DD8452"    # muted orange
C_GREEN = "#55A868"
C_RED = "#C44E52"
C_PURPLE = "#8172B3"
C_GRID = "#E3E6EA"
C_TEXT = "#333333"

plt.rcParams.update({
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.titleweight": "bold",
    "axes.labelsize": 10,
    "axes.edgecolor": "#888888",
    "axes.unicode_minus": False,
    "figure.facecolor": "white",
})


def style_ax(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.5, color=C_GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def save_fig(fig, name):
    path = os.path.join(FIGS, name)
    fig.savefig(path, dpi=200, facecolor="white", edgecolor="none")
    plt.close(fig)
    return path


# ---------------------------------------------------------------- dataset
age = rng.integers(18, 71, N)
income = np.clip(rng.gamma(6.0, 12.0, N), 24, 150).round(1)
spending = np.clip(rng.normal(45 + 0.12 * income, 19, N), 1, 100).round().astype(int)
purchase_freq = np.clip(np.round(2 + 0.20 * spending + rng.normal(0, 4.0, N)), 2, 24).astype(int)
discount = rng.choice(["Low", "Medium", "High"], N, p=[0.30, 0.45, 0.25])
ad_spend = rng.uniform(10, 95, N).round(2)
sales = np.clip(30 + 1.75 * ad_spend + rng.normal(0, 16.0, N), 20, None).round(2)

logit = -3.652 + 0.05 * spending + 0.16 * purchase_freq + rng.normal(0, 0.7, N)
p_yes = 1 / (1 + np.exp(-logit))
response = np.where(rng.uniform(0, 1, N) < p_yes, "Yes", "No")

segment = np.where(income >= 90, "Premium",
           np.where((income < 50) & (spending < 40), "Low-value", "Regular"))

df = pd.DataFrame({
    "Customer_ID": [f"C{i:04d}" for i in range(1, N + 1)],
    "Age": age,
    "Annual_Income": income,
    "Spending_Score": spending,
    "Purchase_Frequency": purchase_freq,
    "Discount_Usage": discount,
    "Ad_Spend": ad_spend,
    "Sales": sales,
    "Campaign_Response": response,
    "Customer_Segment": segment,
})

csv_path = os.path.join(DATA_DIR, "BrightMart_ML_Dataset.csv")
df.to_csv(csv_path, index=False)

M = {}  # master metrics dict
M["seed"] = SEED
M["n_records"] = int(N)
M["n_cols"] = int(df.shape[1])
M["csv_path"] = csv_path

# ---------------------------------------------------------------- Task A
M["dtypes"] = {c: str(t) for c, t in df.dtypes.items()}
head = df.head(5).copy()
M["head_rows"] = [[str(v) for v in row] for row in head.itertuples(index=False)]
M["head_cols"] = list(df.columns)

num_cols = ["Age", "Annual_Income", "Spending_Score", "Purchase_Frequency", "Ad_Spend", "Sales"]
desc = df[num_cols].describe().loc[["count", "mean", "std", "min", "25%", "50%", "75%", "max"]].round(2)
M["desc_cols"] = num_cols
M["desc_rows"] = [[idx] + [f"{v:.2f}" for v in desc.loc[idx]] for idx in desc.index]

M["missing_total"] = int(df.isna().sum().sum())
M["dup_rows"] = int(df.duplicated().sum())
M["dup_ids"] = int(df["Customer_ID"].duplicated().sum())
M["sales_min"] = float(df["Sales"].min())
M["ad_min"] = float(df["Ad_Spend"].min())
M["ad_max"] = float(df["Ad_Spend"].max())
M["income_min"] = float(df["Annual_Income"].min())
M["ss_min"] = int(df["Spending_Score"].min())
M["ss_max"] = int(df["Spending_Score"].max())
M["age_min"] = int(df["Age"].min())
M["age_max"] = int(df["Age"].max())
M["income_cap_count"] = int((df["Annual_Income"] >= 150).sum())
M["income_mean"] = float(df["Annual_Income"].mean())
M["income_median"] = float(df["Annual_Income"].median())

resp_counts = df["Campaign_Response"].value_counts()
M["resp_yes"] = int(resp_counts.get("Yes", 0))
M["resp_no"] = int(resp_counts.get("No", 0))
M["resp_yes_pct"] = round(100 * M["resp_yes"] / N, 1)
M["resp_no_pct"] = round(100 * M["resp_no"] / N, 1)
seg_counts = df["Customer_Segment"].value_counts()
M["seg"] = {k: {"n": int(v), "pct": round(100 * v / N, 1)} for k, v in seg_counts.items()}

M["r_ad_sales"] = round(float(df["Ad_Spend"].corr(df["Sales"])), 3)
M["r_ss_pf"] = round(float(df["Spending_Score"].corr(df["Purchase_Frequency"])), 3)
M["sales_mean"] = round(float(df["Sales"].mean()), 1)
M["sales_min_v"] = round(float(df["Sales"].min()), 1)
M["sales_max_v"] = round(float(df["Sales"].max()), 1)

# ---------------------------------------------------------------- Task B
X_train, X_test, y_train, y_test = train_test_split(
    df[["Ad_Spend"]], df["Sales"], test_size=0.2, random_state=SEED)
lin = LinearRegression().fit(X_train, y_train)
pred = lin.predict(X_test)
M["train_n"] = int(len(X_train))
M["test_n"] = int(len(X_test))
M["slope"] = round(float(lin.coef_[0]), 4)
M["intercept"] = round(float(lin.intercept_), 4)
M["mae"] = round(float(mean_absolute_error(y_test, pred)), 2)
M["r2"] = round(float(r2_score(y_test, pred)), 4)
M["mae_pct_of_mean"] = round(100 * M["mae"] / M["sales_mean"], 1)
M["pred_60"] = round(M["intercept"] + M["slope"] * 60, 2)
M["pred_80"] = round(M["intercept"] + M["slope"] * 80, 2)
M["pred_80_low"] = round(M["pred_80"] - M["mae"], 1)
M["pred_80_high"] = round(M["pred_80"] + M["mae"], 1)
M["delta_60_80"] = round(M["pred_80"] - M["pred_60"], 1)
M["breakeven_margin"] = round(100 / M["slope"], 1)

# ---------------------------------------------------------------- Task C
le = LabelEncoder()
df["Discount_Usage_enc"] = le.fit_transform(df["Discount_Usage"])
M["le_mapping"] = {cls: int(i) for i, cls in enumerate(le.classes_)}
feat_cols = ["Age", "Annual_Income", "Purchase_Frequency", "Spending_Score", "Discount_Usage_enc"]
Xc_train, Xc_test, yc_train, yc_test = train_test_split(
    df[feat_cols], df["Campaign_Response"], test_size=0.2, random_state=SEED)
dt = DecisionTreeClassifier(max_depth=4, random_state=SEED).fit(Xc_train, yc_train)
dt_pred = dt.predict(Xc_test)
M["dt"] = {
    "accuracy": round(100 * accuracy_score(yc_test, dt_pred), 2),
    "precision": round(float(precision_score(yc_test, dt_pred, pos_label="Yes")), 4),
    "recall": round(float(recall_score(yc_test, dt_pred, pos_label="Yes")), 4),
    "f1": round(float(f1_score(yc_test, dt_pred, pos_label="Yes")), 4),
    "cm": confusion_matrix(yc_test, dt_pred, labels=["No", "Yes"]).tolist(),
}
tn, fp, fn, tp = [int(v) for v in np.array(M["dt"]["cm"]).ravel()]
dt_pred_yes = int((dt_pred == "Yes").sum())
M["dt"]["pred_yes_n"] = dt_pred_yes
M["dt"]["acc_correct"] = int(tn + tp)
M["dt"]["actual_yes"] = int((yc_test == "Yes").sum())

# ---- extract decision rules from the fitted tree
feat_names = feat_cols
le_classes = list(le.classes_)  # alphabetical


def cond_text(feature, op, thr):
    if feature == "Discount_Usage_enc":
        keep = [c for i, c in enumerate(le_classes) if (i <= thr if op == "<=" else i > thr)]
        return "Discount_Usage is " + " or ".join(keep)
    return f"{feature} {'<=' if op == '<=' else '>'} {thr:.1f}"


def collapse_conds(conds):
    """Merge repeated conditions on the same feature, keeping the tightest bound."""
    from collections import OrderedDict
    d = OrderedDict()
    for f, op, th in conds:
        d.setdefault(f, []).append((op, th))
    out = []
    for f, pairs in d.items():
        gts = [th for op, th in pairs if op == ">"]
        lts = [th for op, th in pairs if op == "<="]
        if gts:
            out.append((f, ">", max(gts)))
        if lts:
            out.append((f, "<=", min(lts)))
    return out


def extract_leaves(tree, feature_names):
    t = tree.tree_
    out = []

    def rec(node, conds):
        if t.children_left[node] == -1:
            val = t.value[node][0]
            total = int(t.n_node_samples[node])
            frac = val.sum()
            no_n = int(round(total * val[0] / frac))
            yes_n = int(round(total * val[1] / frac))
            out.append({
                "conds": list(conds),
                "n_train": total,
                "no": no_n,
                "yes": yes_n,
                "yes_ratio": float(val[1] / frac),
            })
            return
        f = feature_names[t.feature[node]]
        thr = t.threshold[node]
        conds.append((f, "<=", thr))
        rec(t.children_left[node], conds)
        conds.pop()
        conds.append((f, ">", thr))
        rec(t.children_right[node], conds)
        conds.pop()

    rec(0, [])
    return out


leaves = extract_leaves(dt, feat_names)
yes_leaves = sorted([l for l in leaves if l["n_train"] >= 20],
                    key=lambda l: (l["yes_ratio"], l["n_train"]), reverse=True)
no_leaves = sorted([l for l in leaves if l["n_train"] >= 10],
                   key=lambda l: (1 - l["yes_ratio"], l["n_train"]), reverse=True)

M["dt"]["top_yes_leaves"] = [
    {"conds": [cond_text(f, op, th) for (f, op, th) in collapse_conds(l["conds"])],
     "n": l["n_train"], "yes": l["yes"], "pct": round(100 * l["yes_ratio"])} for l in yes_leaves[:3]]
M["dt"]["top_no_leaves"] = [
    {"conds": [cond_text(f, op, th) for (f, op, th) in collapse_conds(l["conds"])],
     "n": l["n_train"], "no": l["no"], "pct": round(100 * (1 - l["yes_ratio"]))} for l in no_leaves[:3]]
mid = [l for l in leaves if 0.55 <= l["yes_ratio"] <= 0.88 and l["n_train"] >= 15]
mid = sorted(mid, key=lambda l: l["n_train"], reverse=True)
M["dt"]["middle_leaf"] = (
    {"conds": [cond_text(f, op, th) for (f, op, th) in collapse_conds(mid[0]["conds"])],
     "n": mid[0]["n_train"], "yes": mid[0]["yes"], "pct": round(100 * mid[0]["yes_ratio"])}
    if mid else None)

# ---------------------------------------------------------------- Task D
Xk = df[["Annual_Income", "Spending_Score"]].values
scaler = StandardScaler()
Xk_scaled = scaler.fit_transform(Xk)
inertias = []
for k in range(1, 11):
    km = KMeans(n_clusters=k, n_init=10, random_state=SEED).fit(Xk_scaled)
    inertias.append(round(float(km.inertia_), 1))
M["inertias"] = inertias

km3 = KMeans(n_clusters=3, n_init=10, random_state=SEED).fit(Xk_scaled)
df["Cluster"] = km3.labels_
prof = df.groupby("Cluster").agg(
    n=("Cluster", "size"), income=("Annual_Income", "mean"),
    ss=("Spending_Score", "mean"), pf=("Purchase_Frequency", "mean")).round(1)

# assign business labels by profile
low_all = min(prof.index, key=lambda i: (prof.loc[i, "ss"], prof.loc[i, "income"], prof.loc[i, "pf"]))
top_income = max(prof.index, key=lambda i: prof.loc[i, "income"])
remaining = [i for i in prof.index if i not in (low_all, top_income)]
mid_spend = max(remaining, key=lambda i: (prof.loc[i, "ss"], prof.loc[i, "pf"]))
label_map = {int(top_income): "Premium Champions",
             int(mid_spend): "Aspirational Enthusiasts",
             int(low_all): "Budget Conscious"}
M["kmeans"] = {
    "label_map": label_map,
    "clusters": [
        {"cluster": int(i), "label": label_map[int(i)], "n": int(prof.loc[i, "n"]),
         "pct": round(100 * prof.loc[i, "n"] / N, 1), "income": float(prof.loc[i, "income"]),
         "ss": float(prof.loc[i, "ss"]), "pf": float(prof.loc[i, "pf"])}
        for i in prof.index],
    "centroids_orig": scaler.inverse_transform(km3.cluster_centers_).round(1).tolist(),
}

# ---------------------------------------------------------------- Task E
rf = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=SEED).fit(Xc_train, yc_train)
rf_pred = rf.predict(Xc_test)
cm_rf = confusion_matrix(yc_test, rf_pred, labels=["No", "Yes"])
rtn, rfp, rfn, rtp = [int(v) for v in np.array(cm_rf).ravel()]
M["rf"] = {
    "accuracy": round(100 * accuracy_score(yc_test, rf_pred), 2),
    "precision": round(float(precision_score(yc_test, rf_pred, pos_label="Yes")), 4),
    "recall": round(float(recall_score(yc_test, rf_pred, pos_label="Yes")), 4),
    "f1": round(float(f1_score(yc_test, rf_pred, pos_label="Yes")), 4),
    "cm": [[rtn, rfp], [rfn, rtp]],
    "false_neg": rfn, "false_pos": rfp,
    "true_neg": rtn, "true_pos": rtp,
}
M["test_yes_pct"] = round(100 * float((yc_test == "Yes").mean()), 1)
imp = {f: round(float(v), 3) for f, v in zip(feat_names, rf.feature_importances_)}
imp["Discount_Usage"] = imp.pop("Discount_Usage_enc")
M["rf"]["importance"] = imp
M["rf"]["imp_top2_sum_pct"] = round(100 * (imp["Spending_Score"] + imp["Purchase_Frequency"]), 1)

# deltas DT -> RF
M["cmp"] = {
    "acc": round(M["rf"]["accuracy"] - M["dt"]["accuracy"], 2),
    "prec": round(M["rf"]["precision"] - M["dt"]["precision"], 4),
    "rec": round(M["rf"]["recall"] - M["dt"]["recall"], 4),
    "f1": round(M["rf"]["f1"] - M["dt"]["f1"], 4),
    "fn_reduction": int(fn - rfn),
    "fp_reduction": int(fp - rfp),
}

# ================================================================= FIGURES
# ---- Figure 1: EDA grid 2x3
fig, axs = plt.subplots(2, 3, figsize=(13, 7.4), constrained_layout=True)
ax = axs[0, 0]
ax.hist(df["Sales"], bins=20, color=C_PRIMARY, edgecolor="white", linewidth=0.6)
ax.set_title("Sales distribution (\u20b9 thousands)")
ax.set_xlabel("Sales")
ax.set_ylabel("Customers")
style_ax(ax)

ax = axs[0, 1]
ax.scatter(df["Ad_Spend"], df["Sales"], s=14, alpha=0.55, color=C_PRIMARY, edgecolors="none")
ax.set_title("Ad spend vs sales (r = {:.3f})".format(M["r_ad_sales"]))
ax.set_xlabel("Ad_Spend (\u20b9 thousands)")
ax.set_ylabel("Sales (\u20b9 thousands)")
style_ax(ax)

ax = axs[0, 2]
ax.hist(df["Annual_Income"], bins=20, color=C_SECOND, edgecolor="white", linewidth=0.6)
ax.axvline(M["income_median"], color="#555555", linestyle="--", linewidth=1)
ax.set_title("Annual income distribution (\u20b9 lakhs)")
ax.set_xlabel("Annual_Income")
ax.set_ylabel("Customers")
style_ax(ax)

ax = axs[1, 0]
counts = [M["resp_yes"], M["resp_no"]]
bars = ax.bar(["Yes", "No"], counts, color=[C_GREEN, C_RED], width=0.55, edgecolor="white")
for b, v in zip(bars, counts):
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 4, str(v), ha="center", fontsize=10)
ax.set_title("Campaign response ({}% Yes)".format(M["resp_yes_pct"]))
ax.set_ylabel("Customers")
style_ax(ax)

ax = axs[1, 1]
order = ["Regular", "Premium", "Low-value"]
vals = [M["seg"][o]["n"] for o in order]
bars = ax.bar(order, vals, color=[C_PRIMARY, C_SECOND, C_PURPLE], width=0.55, edgecolor="white")
for b, v, o in zip(bars, vals, order):
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 4, f"{v} ({M['seg'][o]['pct']}%)",
            ha="center", fontsize=9)
ax.set_title("Customer segments")
ax.set_ylabel("Customers")
style_ax(ax)

ax = axs[1, 2]
ax.scatter(df["Spending_Score"], df["Purchase_Frequency"], s=14, alpha=0.55, color=C_PURPLE, edgecolors="none")
ax.set_title("Spending score vs purchase frequency (r = {:.3f})".format(M["r_ss_pf"]))
ax.set_xlabel("Spending_Score (1\u2013100)")
ax.set_ylabel("Purchase_Frequency")
style_ax(ax)
save_fig(fig, "fig1_eda.png")

# ---- Figure 2: regression scatter + line
fig, ax = plt.subplots(figsize=(9, 5.4), constrained_layout=True)
ax.scatter(X_test["Ad_Spend"], y_test, s=26, alpha=0.7, color=C_PRIMARY, edgecolors="white", linewidths=0.4,
           label="Actual test-set sales")
xs = np.linspace(df["Ad_Spend"].min(), df["Ad_Spend"].max(), 100)
ax.plot(xs, M["intercept"] + M["slope"] * xs, color=C_RED, linewidth=2.2,
        label="Fitted line: Sales = {:.2f} + {:.4f} \u00d7 Ad_Spend".format(M["intercept"], M["slope"]))
ax.set_xlabel("Ad_Spend (\u20b9 thousands)")
ax.set_ylabel("Sales (\u20b9 thousands)")
ax.set_title("Test-set sales vs ad spend with fitted regression line")
ax.text(0.03, 0.95, "R\u00b2 = {:.4f}   MAE = \u20b9{:.2f}k".format(M["r2"], M["mae"]),
        transform=ax.transAxes, va="top", fontsize=10.5,
        bbox=dict(boxstyle="round,pad=0.4", facecolor="#F2F4F8", edgecolor="#B9C2CE"))
ax.legend(loc="lower right", frameon=False, fontsize=9)
style_ax(ax)
save_fig(fig, "fig2_regression.png")


# ---- Figures 3 & 7: confusion matrices
def cm_figure(cm, title, fname):
    cm = np.array(cm)
    fig, ax = plt.subplots(figsize=(5.6, 4.6), constrained_layout=True)
    im = ax.imshow(cm, cmap="Blues", vmin=0)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Predicted No", "Predicted Yes"])
    ax.set_yticks([0, 1])
    ax.set_yticklabels(["Actual No", "Actual Yes"])
    for i in range(2):
        for j in range(2):
            v = cm[i][j]
            ax.text(j, i, str(v), ha="center", va="center", fontsize=20,
                    color="white" if v > cm.max() * 0.6 else "#1a355e")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, shrink=0.85)
    save_fig(fig, fname)


cm_figure(M["dt"]["cm"], "Decision Tree confusion matrix (test set)", "fig3_dt_cm.png")
cm_figure(M["rf"]["cm"], "Random Forest confusion matrix (test set)", "fig7_rf_cm.png")

# ---- Figure 4: tree plot
fig, ax = plt.subplots(figsize=(19, 8.6), constrained_layout=True)
plot_tree(dt, feature_names=["Age", "Annual_Income", "Purchase_Frequency",
                             "Spending_Score", "Discount_Usage"],
          class_names=["No", "Yes"], filled=True, rounded=True, fontsize=9,
          max_depth=3, ax=ax)
ax.set_title("Decision Tree (max depth 4, drawn to depth 3; leaf values = No / Yes)", fontsize=13)
save_fig(fig, "fig4_tree.png")

# ---- Figure 5: elbow curve
fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
ks = list(range(1, 11))
ax.plot(ks, inertias, marker="o", markersize=6, linewidth=2, color=C_PRIMARY)
ax.axvline(3, color=C_RED, linestyle="--", linewidth=1.4)
ax.annotate("Elbow at K = 3", xy=(3, inertias[2]), xytext=(4.4, inertias[0] * 0.82),
            fontsize=10.5, color="#8a2f2f",
            arrowprops=dict(arrowstyle="->", color="#8a2f2f"))
ax.set_xticks(ks)
ax.set_xlabel("Number of clusters K")
ax.set_ylabel("Within-cluster sum of squares (inertia)")
ax.set_title("Elbow method: inertia for K = 1 to 10")
style_ax(ax)
save_fig(fig, "fig5_elbow.png")

# ---- Figure 6: clusters + centroids (original units)
fig, ax = plt.subplots(figsize=(8.6, 5.8), constrained_layout=True)
colors = {0: C_PRIMARY, 1: C_SECOND, 2: C_GREEN}
for cl in sorted(df["Cluster"].unique()):
    sub = df[df["Cluster"] == cl]
    ax.scatter(sub["Annual_Income"], sub["Spending_Score"], s=16, alpha=0.6,
               color=colors[cl], edgecolors="none",
               label="{} ({})".format(label_map[int(cl)], M["kmeans"]["clusters"][cl]["pct"]))
cents = np.array(M["kmeans"]["centroids_orig"])
ax.scatter(cents[:, 0], cents[:, 1], marker="X", s=210, color="black", edgecolor="white",
           linewidths=1.4, label="Centroids", zorder=5)
ax.set_xlabel("Annual_Income (\u20b9 lakhs)")
ax.set_ylabel("Spending_Score (1\u2013100)")
ax.set_title("K-Means customer segmentation (K = 3) with centroids")
ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9)
style_ax(ax)
save_fig(fig, "fig6_clusters.png")

# ---- Figure 8: feature importance
fig, ax = plt.subplots(figsize=(8, 4.4), constrained_layout=True)
items = sorted(imp.items(), key=lambda kv: kv[1])
names = [k for k, _ in items]
vals = [v for _, v in items]
bars = ax.barh(names, vals, color=C_PRIMARY, height=0.55, edgecolor="white")
for b, v in zip(bars, vals):
    ax.text(b.get_width() + 0.006, b.get_y() + b.get_height() / 2, f"{v:.3f}",
            va="center", fontsize=9.5)
ax.set_xlabel("Importance (mean decrease in impurity)")
ax.set_title("Random Forest feature importance (campaign response)")
ax.set_xlim(0, max(vals) * 1.16)
style_ax(ax)
ax.grid(axis="x", alpha=0.5, color=C_GRID)
ax.grid(axis="y", alpha=0)
save_fig(fig, "fig8_importance.png")

# ---- figure pixel dims for docx embedding
from PIL import Image
M["figs"] = {}
for i, name in enumerate(["fig1_eda.png", "fig2_regression.png", "fig3_dt_cm.png", "fig4_tree.png",
                          "fig5_elbow.png", "fig6_clusters.png", "fig7_rf_cm.png", "fig8_importance.png"], 1):
    p = os.path.join(FIGS, name)
    w, h = Image.open(p).size
    M["figs"][f"fig{i}"] = {"path": p, "w": int(w), "h": int(h)}

with open(os.path.join(ASSETS, "metrics.json"), "w") as f:
    json.dump(M, f, indent=1)

print(json.dumps({k: M[k] for k in ["n_records", "r_ad_sales", "r_ss_pf", "slope", "intercept", "mae",
                                    "r2", "pred_60", "pred_80", "resp_yes_pct", "test_yes_pct",
                                    "breakeven_margin", "delta_60_80"]}, indent=1))
print("DT:", json.dumps(M["dt"], indent=1)[:1600])
print("RF:", json.dumps(M["rf"], indent=1)[:800])
print("KMeans:", json.dumps(M["kmeans"], indent=1)[:1100])
print("inertias:", M["inertias"])
print("leaves_no:", json.dumps(M["dt"]["top_no_leaves"], indent=1))
print("middle:", json.dumps(M["dt"]["middle_leaf"], indent=1))
print("seg:", json.dumps(M["seg"], indent=1))
print("OK")
